<?php
$lang['client_list'] = ' Cliënten lijst';
$lang['all_client'] = ' alle klanten';
$lang['name'] = ' Naam';
$lang['client'] = ' Cliënt';
$lang['clients'] = ' cliënten';
$lang['client_status'] = ' Select Type';
$lang['select'] = ' kiezen';
$lang['manage_client'] = ' Manage Client';
$lang['clients_registration'] = ' cliënten Registraties';
$lang['clients_registered'] = ' cliënten Geregistreerd';
$lang['client_registered_successfully'] = ' registratie Client succes!';
$lang['activity_added_new_company'] = ' Voeg nieuwe Client';
$lang['activity_update_company'] = ' Update van nieuwe Client';
$lang['activity_update_contact'] = ' Update van nieuwe Contact';
$lang['activity_added_new_contact'] = ' Voeg nieuw contact toe';
$lang['activity_deleted_contact'] = ' Contactpersoon verwijderen';
$lang['delete_contact'] = ' Klant Contact Informatie succesvol verwijderd!  ';
$lang['activity_deleted_client'] = ' verwijderde Client';
$lang['delete_client'] = ' Client Information succesvol verwijderd!';
$lang['select_type'] = ' Select Type';
$lang['client_contact'] = ' Contact';
$lang['hosting'] = ' hosting';
$lang['converted_from'] = ' Converted Form';
$lang['without_converted'] = ' zonder Converted';
$lang['converted_client'] = ' Converted Client';


/* End of file client_lang.php */
/* Location: ./application/language/dutch/client_lang.php */
