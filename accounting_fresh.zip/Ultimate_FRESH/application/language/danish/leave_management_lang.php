<?php
$lang['leave_management'] = 'Lad ';
$lang['my_leave'] = 'min ';
$lang['all_leave'] = 'Alle ';
$lang['new_leave'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['leave_report'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['all_required_fill'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['current_date_error'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['end_date_less_than_error'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['leave_successfully_save'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['leave_date_conflict'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['application_details'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['leave_from'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['leave_to'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['details_of'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['applied_on'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['at'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['approved_by'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['approved'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['reject'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['rejected'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['give_comment'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['application_status_changed'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['leave_application_delete'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['activity_leave_deleted'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['activity_leave_save'] = 'Venligst Fyld alle nødvendige fyld til at anvende';
$lang['activity_leave_change'] = 'Venligst Fyld alle nødvendige fyld til at anvende';


/* End of file leave_management_lang.php */
/* Location: ./application/language/danish/leave_management_lang.php */
