<?php
$lang['stock'] = 'lager';
$lang['stock_category'] = 'Stock Kategori';
$lang['add_stock'] = 'Tilføj ';
$lang['manage_stock'] = 'Administration af papir';
$lang['stock_history'] = 'Administration af papir';
$lang['stock_list'] = 'Administration af papir';
$lang['assign_stock'] = 'Administration af papir';
$lang['assign_stock_list'] = 'Administration af papir';
$lang['stock_report'] = 'Administration af papir';
$lang['sub_category'] = 'Administration af papir';
$lang['undefined_category'] = 'Administration af papir';
$lang['alert_delete_category'] = 'Administration af papir';
$lang['activity_added_stock_category'] = 'Administration af papir';
$lang['activity_update_stock_category'] = 'Administration af papir';
$lang['activity_delete_item_history'] = 'Administration af papir';
$lang['stock_successfully_added'] = 'Administration af papir';
$lang['stock_history_deleted'] = 'Administration af papir';
$lang['stock_deleted'] = 'Administration af papir';
$lang['activity_delete_stock'] = 'Administration af papir';
$lang['category_added_successfully'] = 'Administration af papir';
$lang['category_already_exist'] = 'Administration af papir';
$lang['stock_already_exist'] = 'Administration af papir';
$lang['sub_category_already_exist'] = 'Administration af papir';
$lang['sub_category_deleted'] = 'Administration af papir';
$lang['inventory'] = 'Administration af papir';
$lang['buying_date'] = 'Administration af papir';
$lang['total_stock'] = 'Administration af papir';
$lang['assign_quantity'] = 'Administration af papir';
$lang['enter'] = 'Administration af papir';
$lang['assign_date'] = 'Administration af papir';
$lang['exceed_stock'] = 'Administration af papir';
$lang['assign_success'] = 'Administration af papir';
$lang['assigned_user'] = 'Administration af papir';
$lang['assign_stock_report'] = 'Administration af papir';
$lang['assign_stock_deleted'] = 'Administration af papir';
$lang['activity_assign_stock'] = 'Administration af papir';
$lang['activity_delete_assign_stock'] = 'Administration af papir';
$lang['assign_stock_list_for'] = 'Administration af papir';
$lang['search'] = 'Administration af papir';
$lang['report_list'] = 'Administration af papir';
$lang['available_stock'] = 'Administration af papir';
$lang['report_from'] = 'Administration af papir';
$lang['report_to'] = 'Administration af papir';


/* End of file stock_lang.php */
/* Location: ./application/language/danish/stock_lang.php */
