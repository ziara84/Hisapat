<?php
$lang['menu_permission'] = 'إذن القائمة';
$lang['module'] = 'وحدة';
$lang['department_update'] = 'قسم السينما الكويتية بنجاح تحديث';
$lang['designation_info_deleted'] = 'تسمية السينما الكويتية المحذوفة بنجاح';
$lang['no_designation_create_yet'] = 'لا تسمية إنشاء بعد';
$lang['department_already_used'] = 'معلومات قسم مستعمل إذا';
$lang['undefined_department'] = 'قسم غير محدد';
$lang['activity_update_a_department'] = 'وزارة تحديث';
$lang['activity_delete_a_department'] = 'وزارة محذوفة';
$lang['activity_delete_a_designation'] = 'تعيين محذوفة';


/* End of file departments_lang.php */
/* Location: ./application/language/arabic/departments_lang.php */
