<?php
$lang['client_list'] = 'Seznam Client';
$lang['all_client'] = 'Všichni klienti';
$lang['name'] = 'Jméno';
$lang['client'] = 'zákazník';
$lang['clients'] = 'klienti';
$lang['client_status'] = 'Vyberte typ';
$lang['select'] = 'Vybrat';
$lang['manage_client'] = 'Správa klienta';
$lang['clients_registration'] = 'klienti Registrace';
$lang['clients_registered'] = 'klienti Registrované';
$lang['client_registered_successfully'] = 'registrace klienta úspěšný!';
$lang['activity_added_new_company'] = 'Přidat nový klient';
$lang['activity_update_company'] = 'Aktualizovat novým klientem';
$lang['activity_update_contact'] = 'Aktualizace nových Kontakt';
$lang['activity_added_new_contact'] = 'Přidat nový kontakt';
$lang['activity_deleted_contact'] = 'Odstranit kontakt';
$lang['delete_contact'] = 'Klient Kontaktní údaje úspěšně smazána!';
$lang['activity_deleted_client'] = 'vypouští Client';
$lang['delete_client'] = 'nformace o klientovi byla úspěšně odstraněna!';
$lang['select_type'] = 'Vyberte typ';
$lang['client_contact'] = 'Kontakt';
$lang['hosting'] = 'klientovi';
$lang['converted_from'] = 'zpracované formě';
$lang['without_converted'] = 'bez Převedené';
$lang['converted_client'] = 'V přepočtu ';


/* End of file client_lang.php */
/* Location: ./application/language/czech/client_lang.php */
