<?php
$lang['recent_leads'] = '最近的信息';
$lang['source'] = '源';
$lang['facebook_profile_link'] = '网址';
$lang['twitter_profile_link'] = '网址';
$lang['linkedin_profile_link'] = '网址';
$lang['leads_name'] = '信息名称';
$lang['mettings_deleted'] = '信息删除成功';
$lang['convert'] = '兑换';
$lang['convert_to_client'] = '转换到客户端';
$lang['activity_convert_to_client'] = '转换导致客户端';
$lang['convert_to_client_suucess'] = '转换导致客户端成功';
$lang['import_leads'] = '进口信息';


/* End of file leads_lang.php */
/* Location: ./application/language/chinese/leads_lang.php */
